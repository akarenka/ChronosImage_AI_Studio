@echo off
cd /d "%~dp0"
title AI Image Studio v2 Diagnose

echo Project folder:
echo %CD%
echo.

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] .venv was not found.
  echo Run Install.bat first.
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"

echo === Python ===
python --version
echo.

echo === Torch / CUDA ===
python -c "import torch; print('torch=',torch.__version__); print('cuda=',torch.cuda.is_available()); print('gpu=',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None')"
echo.

echo === Flask ===
python -c "import flask; print('flask=',flask.__version__)"
echo.

echo === Hugging Face connection ===
python -c "from huggingface_hub import model_info; print(model_info('runwayml/stable-diffusion-v1-5').modelId)"
echo.

echo === NVIDIA SMI ===
nvidia-smi
echo.

echo === Disk free space ===
powershell -NoProfile -Command "Get-PSDrive -PSProvider FileSystem | Select Name,@{N='FreeGB';E={[math]::Round($_.Free/1GB,1)}}"
echo.

echo === Required files ===
for %%F in (index.html server.py start_server.bat Install_AI_Requirements.bat requirements.txt) do (
  if exist "%%F" (echo [OK] %%F) else (echo [MISSING] %%F)
)
echo.
pause
