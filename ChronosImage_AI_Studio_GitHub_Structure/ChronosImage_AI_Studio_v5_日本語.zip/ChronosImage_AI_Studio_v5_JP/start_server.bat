@echo off
cd /d "%~dp0"
title AI Image Studio CMD Edition
where python >nul 2>nul || (echo Python not found.& pause & exit /b 1)
if not exist ".venv\Scripts\python.exe" python -m venv .venv
call ".venv\Scripts\activate.bat"
python -c "import flask" >nul 2>nul || python -m pip install Flask
python server.py
pause
