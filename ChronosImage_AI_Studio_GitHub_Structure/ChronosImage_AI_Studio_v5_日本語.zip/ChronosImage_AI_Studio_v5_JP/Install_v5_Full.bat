@echo off
setlocal
cd /d "%~dp0"
title ChronosImage AI Studio v5 Installer

set "PIP_CACHE_DIR=%CD%\cache\pip"
set "TMP=%CD%\cache\temp"
set "TEMP=%CD%\cache\temp"
set "HF_HOME=%CD%\cache\huggingface"
set "TORCH_HOME=%CD%\cache\torch"
set "TRANSFORMERS_CACHE=%CD%\cache\transformers"

if exist "Install_v4_Full.bat" (
  call Install_v4_Full.bat
) else (
  call Install_v3_Full.bat
)

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Installation failed.
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade Flask huggingface-hub tqdm filelock psutil requests

echo.
echo ============================================================
echo v5 installation completed.
echo New caches are inside:
echo %CD%\cache
echo ============================================================
pause
