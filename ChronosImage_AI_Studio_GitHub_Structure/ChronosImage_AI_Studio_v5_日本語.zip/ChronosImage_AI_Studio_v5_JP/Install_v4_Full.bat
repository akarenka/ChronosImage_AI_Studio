@echo off
cd /d "%~dp0"
title ChronosImage AI Studio v4 Installer

call Install_v3_Full.bat
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Virtual environment installation failed.
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade huggingface-hub tqdm filelock

echo.
echo ====================================================
echo Installation complete.
echo Next: run Model_Manager.bat before generating images.
echo ====================================================
pause
