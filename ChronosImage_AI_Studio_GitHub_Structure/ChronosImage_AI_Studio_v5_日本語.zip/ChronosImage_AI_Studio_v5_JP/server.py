from __future__ import annotations
import json, os, platform, shutil, signal, subprocess, sys, threading, time, uuid, logging
from pathlib import Path
from typing import Any
from flask import Flask, jsonify, request, send_file, send_from_directory

BASE_DIR=Path(__file__).resolve().parent

# Keep large AI caches inside this project instead of C:\Users\<name>\.cache.
PROJECT_CACHE_DIR = BASE_DIR / "cache"
HF_HOME_DIR = PROJECT_CACHE_DIR / "huggingface"
TORCH_HOME_DIR = PROJECT_CACHE_DIR / "torch"
TRANSFORMERS_CACHE_DIR = PROJECT_CACHE_DIR / "transformers"
PIP_CACHE_DIR = PROJECT_CACHE_DIR / "pip"
TEMP_CACHE_DIR = PROJECT_CACHE_DIR / "temp"
for _folder in (
    PROJECT_CACHE_DIR, HF_HOME_DIR, TORCH_HOME_DIR,
    TRANSFORMERS_CACHE_DIR, PIP_CACHE_DIR, TEMP_CACHE_DIR
):
    _folder.mkdir(parents=True, exist_ok=True)

os.environ["HF_HOME"] = str(HF_HOME_DIR)
os.environ["HF_HUB_CACHE"] = str(HF_HOME_DIR / "hub")
os.environ["HUGGINGFACE_HUB_CACHE"] = str(HF_HOME_DIR / "hub")
os.environ["TRANSFORMERS_CACHE"] = str(TRANSFORMERS_CACHE_DIR)
os.environ["TORCH_HOME"] = str(TORCH_HOME_DIR)
os.environ["PIP_CACHE_DIR"] = str(PIP_CACHE_DIR)
os.environ["TMP"] = str(TEMP_CACHE_DIR)
os.environ["TEMP"] = str(TEMP_CACHE_DIR)
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "600")
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "60")

# Hide repetitive GET /api/status access lines. Real AI task logs remain visible.
logging.getLogger("werkzeug").setLevel(logging.ERROR)
LOCAL_SDXL_DIR=BASE_DIR/"models"/"checkpoints"/"sdxl-base-1.0"
LOCAL_SD15_DIR=BASE_DIR/"models"/"checkpoints"/"sd15"
LOCAL_CONTROLNET_DIR=BASE_DIR/"models"/"controlnet"/"openpose-sdxl"
LOCAL_ANNOTATORS_DIR=BASE_DIR/"models"/"controlnet"/"annotators"
LOCAL_VAE_DIR=BASE_DIR/"models"/"vae"/"sdxl-vae-fp16-fix"
RUNTIME_DIR=BASE_DIR/"runtime"; OUTPUT_DIR=BASE_DIR/"output"; TRAIN_DIR=RUNTIME_DIR/"train_images"
CHECKPOINT_DIR=BASE_DIR/"models"/"checkpoints"
LORA_DIR=BASE_DIR/"models"/"loras"
CONTROLNET_DIR=BASE_DIR/"models"/"controlnet"
UPSCALER_DIR=BASE_DIR/"models"/"upscalers"
IPADAPTER_DIR=BASE_DIR/"models"/"ipadapter"
WORKFLOW_DIR=BASE_DIR/"workflows"
PRESET_DIR=BASE_DIR/"presets"
STORYBOARD_DIR=BASE_DIR/"storyboards"
for d in (CHECKPOINT_DIR,LORA_DIR,CONTROLNET_DIR,UPSCALER_DIR,IPADAPTER_DIR,WORKFLOW_DIR,PRESET_DIR,STORYBOARD_DIR):
    d.mkdir(parents=True,exist_ok=True)
for d in (RUNTIME_DIR,OUTPUT_DIR,TRAIN_DIR): d.mkdir(parents=True,exist_ok=True)
app=Flask(__name__,static_folder=None)
_lock=threading.Lock(); _process=None; _outputs={}
_state={"state":"Idle","mode":None,"progress":0,"logs":["AI Image Studio backend ready."],"output_file":None,"completed_output_id":None,"elapsed_seconds":0,"last_activity":"等待工作"}

def log(m):
    with _lock:
        _state["logs"].append(str(m)); _state["logs"]=_state["logs"][-600:]
def update(**kw):
    with _lock: _state.update(kw)
def gpu():
    try:
        r=subprocess.run(["nvidia-smi","--query-gpu=name,memory.used,memory.total","--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=4)
        n,u,t=[x.strip() for x in r.stdout.strip().splitlines()[0].split(",")[:3]]
        return f"{n} · {u}/{t} MB"
    except Exception: return "未偵測 NVIDIA GPU"
def safe(n):
    s="".join(c for c in Path(n).name if c.isalnum() or c in "._- ")
    return s[:120] or "input.png"

def script_for(mode,p,input_path,output_path):
    prompt=json.dumps(str(p.get("prompt","")),ensure_ascii=False)
    negative=json.dumps(str(p.get("negative","")),ensure_ascii=False)
    model=json.dumps(str(p.get("model","runwayml/stable-diffusion-v1-5")))
    seed=int(p.get("seed",12345)); steps=int(p.get("steps",30)); guidance=float(p.get("guidance",7.5)); strength=float(p.get("strength",0.65)); res=int(p.get("resolution",512))
    common = """import os
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT","600")
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT","60")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY","1")
os.environ.setdefault("TOKENIZERS_PARALLELISM","false")
"""
    if mode=="img2img":
        return common+f"""
import torch
from PIL import Image
from huggingface_hub import snapshot_download
from diffusers import StableDiffusionImg2ImgPipeline

MODEL_ID={model}
PROMPT={prompt}
NEGATIVE={negative}
INPUT=r"{input_path}"
OUTPUT=r"{output_path}"

print("[STAGE] Checking model cache", flush=True)
print("[PROGRESS] 3", flush=True)
snapshot_download(MODEL_ID, max_workers=2)
print("[STAGE] Model files ready", flush=True)
print("[PROGRESS] 18", flush=True)

device="cuda" if torch.cuda.is_available() else "cpu"
dtype=torch.float16 if device=="cuda" else torch.float32
print("[STAGE] Loading Img2Img pipeline", flush=True)
pipe=StableDiffusionImg2ImgPipeline.from_pretrained(
    MODEL_ID, torch_dtype=dtype, use_safetensors=True, local_files_only=True
)
if device=="cuda":
    pipe=pipe.to(device)
else:
    pipe=pipe.to("cpu")
print("[PROGRESS] 42", flush=True)

img=Image.open(INPUT).convert("RGB").resize(({res},{res}))
gen=torch.Generator(device=device).manual_seed({seed})
print("[STAGE] Generating image", flush=True)
print("[PROGRESS] 50", flush=True)
out=pipe(
    prompt=PROMPT,negative_prompt=NEGATIVE,image=img,
    strength={strength},guidance_scale={guidance},
    num_inference_steps={steps},generator=gen
).images[0]
print("[PROGRESS] 95", flush=True)
out.save(OUTPUT)
print("[PROGRESS] 100", flush=True)
print("Saved:",OUTPUT, flush=True)
"""
    if mode=="controlnet":
        return common+f"""
import torch
from PIL import Image
from huggingface_hub import snapshot_download
from diffusers import StableDiffusionXLControlNetPipeline, ControlNetModel
from controlnet_aux import OpenposeDetector

BASE_MODEL={model}
CONTROLNET_MODEL="thibaud/controlnet-openpose-sdxl-1.0"
POSE_MODEL="lllyasviel/Annotators"
PROMPT={prompt}
NEGATIVE={negative}
INPUT=r"{input_path}"
OUTPUT=r"{output_path}"

print("[STAGE] Download/check SDXL base model", flush=True)
print("[PROGRESS] 2", flush=True)
snapshot_download(BASE_MODEL, max_workers=2)
print("[PROGRESS] 10", flush=True)

print("[STAGE] Download/check ControlNet model", flush=True)
snapshot_download(CONTROLNET_MODEL, max_workers=2)
print("[PROGRESS] 17", flush=True)

print("[STAGE] Download/check OpenPose detector", flush=True)
snapshot_download(POSE_MODEL, allow_patterns=["*.pth","*.pt","*.yaml","*.json"], max_workers=2)
print("[PROGRESS] 22", flush=True)

device="cuda" if torch.cuda.is_available() else "cpu"
dtype=torch.float16 if device=="cuda" else torch.float32

print("[STAGE] Extracting OpenPose skeleton", flush=True)
pose_detector=OpenposeDetector.from_pretrained("lllyasviel/Annotators")
pose=pose_detector(Image.open(INPUT).convert("RGB"))
pose.save(r"{output_path.with_name(output_path.stem+'_pose.png')}")
print("[PROGRESS] 30", flush=True)

print("[STAGE] Loading ControlNet", flush=True)
controlnet=ControlNetModel.from_pretrained(
    CONTROLNET_MODEL,torch_dtype=dtype,use_safetensors=True,local_files_only=True
)
print("[PROGRESS] 42", flush=True)

print("[STAGE] Loading SDXL pipeline", flush=True)
pipe=StableDiffusionXLControlNetPipeline.from_pretrained(
    BASE_MODEL,controlnet=controlnet,torch_dtype=dtype,
    use_safetensors=True,local_files_only=True
)
if device=="cuda":
    try:
        pipe.enable_model_cpu_offload()
    except Exception:
        pipe=pipe.to("cuda")
else:
    pipe=pipe.to("cpu")
print("[PROGRESS] 58", flush=True)

gen=torch.Generator(device=device).manual_seed({seed})
print("[STAGE] Generating image", flush=True)
out=pipe(
    prompt=PROMPT,negative_prompt=NEGATIVE,image=pose,
    num_inference_steps={steps},guidance_scale={guidance},generator=gen
).images[0]
print("[PROGRESS] 95", flush=True)
out.save(OUTPUT)
print("[PROGRESS] 100", flush=True)
print("Saved:",OUTPUT, flush=True)
"""
    return common+f"""
print("[PROGRESS] 10", flush=True)
print("[STAGE] Preparing LoRA training images", flush=True)
print("LoRA images prepared in:",r"{TRAIN_DIR}", flush=True)
print("Prompt:",{prompt}, flush=True)
print("Steps:",{int(p.get("trainSteps",500))}, flush=True)
print("Learning rate:",{float(p.get("learningRate",0.0001))}, flush=True)
print("Use kohya_ss or diffusers train_dreambooth_lora.py for production training.", flush=True)
print("[PROGRESS] 100", flush=True)
"""

def reader(proc,mode,out):
    global _process
    started=time.time()
    last_line_time=time.time()
    buffer=""
    stop_heartbeat=threading.Event()

    def handle_line(line):
        nonlocal last_line_time
        line=line.strip()
        if not line:
            return
        last_line_time=time.time()
        if line.startswith("[PROGRESS]"):
            try:update(progress=max(0,min(100,int(line.split("]",1)[1].strip()))))
            except:pass
        elif line.startswith("[STAGE]"):
            stage=line.split("]",1)[1].strip()
            update(last_activity=stage)
            log("▶ "+stage)
        else:
            # Avoid flooding the browser with duplicate tqdm lines.
            with _lock:
                previous=_state["logs"][-1] if _state["logs"] else ""
            if line != previous:
                log(line)

    def heartbeat():
        while not stop_heartbeat.wait(10):
            elapsed=int(time.time()-started)
            quiet=int(time.time()-last_line_time)
            update(elapsed_seconds=elapsed)
            if quiet>=20 and proc.poll() is None:
                stage=_state.get("last_activity") or "模型下載/載入"
                log(f"… 工作仍在執行：{stage}（已經過 {elapsed} 秒，最近 {quiet} 秒沒有新輸出）")

    threading.Thread(target=heartbeat,daemon=True).start()
    try:
        # tqdm often uses carriage returns instead of newlines. Reading one
        # character at a time lets the web console receive these updates.
        while True:
            ch=proc.stdout.read(1)
            if ch=="":
                if proc.poll() is not None:
                    break
                time.sleep(.05)
                continue
            if ch in ("\n","\r"):
                if buffer:
                    handle_line(buffer)
                    buffer=""
            else:
                buffer+=ch
        if buffer:
            handle_line(buffer)

        code=proc.wait()
        if code==0:
            oid=None
            if out.exists(): oid=uuid.uuid4().hex; _outputs[oid]=out
            update(state="Completed",progress=100,output_file=out.name if out.exists() else "No image output",completed_output_id=oid,last_activity="完成")
            log("Task completed.")
        else:
            update(state="Failed",last_activity="執行失敗")
            log(f"Task exited with code {code}.")
    except Exception as e:
        update(state="Failed",last_activity="後端錯誤")
        log(e)
    finally:
        stop_heartbeat.set()
        _process=None

@app.get("/")
def root(): return send_from_directory(BASE_DIR,"index.html")
@app.get("/<path:name>")
def asset(name):
    p=BASE_DIR/name
    return send_from_directory(BASE_DIR,name) if p.is_file() else (jsonify(error="Not found"),404)
@app.get("/api/health")
def health(): return jsonify(ok=True,gpu=gpu(),python=sys.version.split()[0],platform=platform.platform())
@app.get("/api/status")
def status():
    with _lock:return jsonify(dict(_state))
@app.post("/api/open-cmd")
def open_cmd():
    if os.name!="nt":return jsonify(error="Open CMD is Windows only."),400
    subprocess.Popen(["cmd.exe","/K",f'cd /d "{BASE_DIR}"'],creationflags=subprocess.CREATE_NEW_CONSOLE)
    return jsonify(ok=True)
@app.post("/api/open-output")
def open_output():
    if os.name=="nt":os.startfile(OUTPUT_DIR)
    elif sys.platform=="darwin":subprocess.Popen(["open",str(OUTPUT_DIR)])
    else:subprocess.Popen(["xdg-open",str(OUTPUT_DIR)])
    return jsonify(ok=True)
@app.post("/api/stop")
def stop():
    global _process
    if not _process or _process.poll() is not None:return jsonify(ok=True)
    if os.name=="nt":subprocess.run(["taskkill","/PID",str(_process.pid),"/T","/F"],capture_output=True)
    else:os.killpg(os.getpgid(_process.pid),signal.SIGTERM)
    update(state="Stopped");log("Task stopped by user.");return jsonify(ok=True)
@app.post("/api/run")
def run_task():
    global _process
    if _process and _process.poll() is None:return jsonify(error="A task is already running."),409
    try:p=json.loads(request.form.get("params","{}"))
    except:return jsonify(error="Invalid params."),400
    mode=str(p.get("mode","img2img")); images=request.files.getlist("images")
    if not images:return jsonify(error="No image uploaded."),400
    jid=time.strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6]; job=RUNTIME_DIR/jid; job.mkdir(parents=True,exist_ok=True)
    if mode=="lora":
        if TRAIN_DIR.exists():shutil.rmtree(TRAIN_DIR)
        TRAIN_DIR.mkdir(parents=True)
        for f in images:f.save(TRAIN_DIR/safe(f.filename or "train.png"))
        inp=TRAIN_DIR; out=OUTPUT_DIR/f"lora_{jid}.txt"
    else:
        f=images[0]; inp=job/safe(f.filename or "input.png"); f.save(inp); out=OUTPUT_DIR/f"{mode}_{jid}.png"
    sp=job/f"run_{mode}.py"; sp.write_text(script_for(mode,p,inp,out),encoding="utf-8")
    kwargs={}
    if os.name!="nt":kwargs["start_new_session"]=True
    child_env=os.environ.copy()
    child_env.update({
        "PYTHONUNBUFFERED":"1",
        "HF_HUB_DOWNLOAD_TIMEOUT":"600",
        "HF_HUB_ETAG_TIMEOUT":"60",
        "HF_HUB_DISABLE_TELEMETRY":"1",
        "HF_HOME":str(HF_HOME_DIR),
        "HF_HUB_CACHE":str(HF_HOME_DIR / "hub"),
        "HUGGINGFACE_HUB_CACHE":str(HF_HOME_DIR / "hub"),
        "TRANSFORMERS_CACHE":str(TRANSFORMERS_CACHE_DIR),
        "TORCH_HOME":str(TORCH_HOME_DIR),
        "PIP_CACHE_DIR":str(PIP_CACHE_DIR),
        "TMP":str(TEMP_CACHE_DIR),
        "TEMP":str(TEMP_CACHE_DIR)
    })
    proc=subprocess.Popen([sys.executable,"-u",str(sp)],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding="utf-8",errors="replace",bufsize=0,env=child_env,creationflags=(subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0),**kwargs)
    _process=proc;update(state="Running",mode=mode,progress=1,logs=[f"Started {mode}.",f"Script: {sp}"],output_file=None,completed_output_id=None,elapsed_seconds=0,last_activity="啟動中")
    threading.Thread(target=reader,args=(proc,mode,out),daemon=True).start()
    return jsonify(ok=True,job_id=jid)
@app.get("/api/output/<oid>")
def output(oid):
    p=_outputs.get(oid)
    if not p or not p.exists():return jsonify(error="Output not found."),404
    r=send_file(p,mimetype="image/png");r.headers["X-Filename"]=p.name;return r

@app.get("/api/models")
def list_models():
    def scan(folder):
        rows=[]
        for p in sorted(folder.glob("**/*")):
            if p.is_file() and p.suffix.lower() in {".safetensors",".ckpt",".pt",".pth",".bin",".onnx"}:
                rows.append({"name":p.name,"path":str(p.relative_to(BASE_DIR)),"size":p.stat().st_size})
        return rows
    return jsonify(
        checkpoints=scan(CHECKPOINT_DIR),
        loras=scan(LORA_DIR),
        controlnet=scan(CONTROLNET_DIR),
        upscalers=scan(UPSCALER_DIR),
        ipadapter=scan(IPADAPTER_DIR)
    )

@app.post("/api/preset")
def save_preset():
    data=request.get_json(silent=True) or {}
    name=safe(str(data.get("name","preset")))+".json"
    (PRESET_DIR/name).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    return jsonify(ok=True,name=name)

@app.get("/api/presets")
def list_presets():
    items=[]
    for p in sorted(PRESET_DIR.glob("*.json")):
        try: items.append(json.loads(p.read_text(encoding="utf-8")))
        except Exception: pass
    return jsonify(items=items)

@app.post("/api/storyboard")
def storyboard():
    data=request.get_json(silent=True) or {}
    title=safe(str(data.get("title","storyboard")))
    scenes=data.get("scenes",[])
    out={"title":title,"created_at":time.time(),"scenes":scenes}
    path=STORYBOARD_DIR/f"{title}_{int(time.time())}.json"
    path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    return jsonify(ok=True,file=path.name)

@app.get("/api/self-test")
def self_test():
    checks={}
    checks["python"]=sys.version.split()[0]
    checks["flask"]=True
    checks["nvidia_smi"]=gpu()
    try:
        import torch
        checks["torch"]=torch.__version__
        checks["cuda"]=bool(torch.cuda.is_available())
    except Exception as e:
        checks["torch_error"]=str(e)
    checks["folders"]={name:str(path.exists()) for name,path in {
        "checkpoints":CHECKPOINT_DIR,"loras":LORA_DIR,"controlnet":CONTROLNET_DIR,
        "upscalers":UPSCALER_DIR,"ipadapter":IPADAPTER_DIR,"output":OUTPUT_DIR
    }.items()}
    return jsonify(checks=checks)

@app.post("/api/upscale")
def upscale():
    image=request.files.get("image")
    scale=int(request.form.get("scale","2"))
    if not image:return jsonify(error="No image"),400
    from PIL import Image
    jid=time.strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6]
    inp=RUNTIME_DIR/f"upscale_{jid}_{safe(image.filename or 'input.png')}"
    image.save(inp)
    out=OUTPUT_DIR/f"upscaled_{jid}.png"
    im=Image.open(inp).convert("RGB")
    im=im.resize((im.width*scale,im.height*scale),Image.Resampling.LANCZOS)
    im.save(out)
    oid=uuid.uuid4().hex;_outputs[oid]=out
    return jsonify(ok=True,output_id=oid,name=out.name)

@app.post("/api/face-enhance")
def face_enhance():
    image=request.files.get("image")
    if not image:return jsonify(error="No image"),400
    from PIL import Image,ImageEnhance,ImageFilter
    jid=time.strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6]
    inp=RUNTIME_DIR/f"face_{jid}_{safe(image.filename or 'input.png')}"
    image.save(inp)
    out=OUTPUT_DIR/f"face_enhanced_{jid}.png"
    im=Image.open(inp).convert("RGB")
    im=ImageEnhance.Sharpness(im).enhance(1.35)
    im=ImageEnhance.Contrast(im).enhance(1.06)
    im.save(out)
    oid=uuid.uuid4().hex;_outputs[oid]=out
    return jsonify(ok=True,output_id=oid,name=out.name,note="Fallback enhancement used; install CodeFormer/GFPGAN for neural restoration.")

@app.post("/api/color-correct")
def color_correct():
    image=request.files.get("image")
    if not image:return jsonify(error="No image"),400
    from PIL import Image,ImageEnhance
    jid=time.strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6]
    inp=RUNTIME_DIR/f"color_{jid}_{safe(image.filename or 'input.png')}"
    image.save(inp)
    out=OUTPUT_DIR/f"color_corrected_{jid}.png"
    im=Image.open(inp).convert("RGB")
    im=ImageEnhance.Color(im).enhance(float(request.form.get("saturation","1.08")))
    im=ImageEnhance.Contrast(im).enhance(float(request.form.get("contrast","1.05")))
    im=ImageEnhance.Brightness(im).enhance(float(request.form.get("brightness","1.02")))
    im.save(out)
    oid=uuid.uuid4().hex;_outputs[oid]=out
    return jsonify(ok=True,output_id=oid,name=out.name)

@app.post("/api/batch-run")
def batch_run():
    return jsonify(ok=True,message="Batch queue registered. Submit each item through /api/run in sequence from the web UI.")

@app.get("/api/integrations")
def integrations():
    return jsonify(
        automatic1111={"url":"http://127.0.0.1:7860","status":"configurable"},
        comfyui={"url":"http://127.0.0.1:8188","status":"configurable"},
        kohya_ss={"url":"http://127.0.0.1:7861","status":"configurable"}
    )

@app.get("/api/offline-models")
def offline_models():
    def info(path):
        size=0
        exists=path.exists() and any(path.rglob("*"))
        if path.exists():
            for p in path.rglob("*"):
                if p.is_file():
                    try:size+=p.stat().st_size
                    except Exception:pass
        return {"exists":exists,"path":str(path),"size":size}
    return jsonify(
        sdxl=info(LOCAL_SDXL_DIR),
        sd15=info(LOCAL_SD15_DIR),
        controlnet=info(LOCAL_CONTROLNET_DIR),
        annotators=info(LOCAL_ANNOTATORS_DIR),
        vae=info(LOCAL_VAE_DIR)
    )

def _folder_size(folder):
    total = 0
    if folder.exists():
        for item in folder.rglob("*"):
            if item.is_file():
                try:
                    total += item.stat().st_size
                except OSError:
                    pass
    return total

@app.get("/api/cache-info")
def cache_info():
    return jsonify(
        project_cache=str(PROJECT_CACHE_DIR),
        huggingface={"path":str(HF_HOME_DIR),"bytes":_folder_size(HF_HOME_DIR)},
        torch={"path":str(TORCH_HOME_DIR),"bytes":_folder_size(TORCH_HOME_DIR)},
        transformers={"path":str(TRANSFORMERS_CACHE_DIR),"bytes":_folder_size(TRANSFORMERS_CACHE_DIR)},
        pip={"path":str(PIP_CACHE_DIR),"bytes":_folder_size(PIP_CACHE_DIR)},
        temp={"path":str(TEMP_CACHE_DIR),"bytes":_folder_size(TEMP_CACHE_DIR)}
    )

@app.post("/api/clear-project-cache")
def clear_project_cache():
    data = request.get_json(silent=True) or {}
    cache_type = str(data.get("type", "all"))
    mapping = {
        "huggingface": HF_HOME_DIR,
        "torch": TORCH_HOME_DIR,
        "transformers": TRANSFORMERS_CACHE_DIR,
        "pip": PIP_CACHE_DIR,
        "temp": TEMP_CACHE_DIR,
    }
    targets = list(mapping.values()) if cache_type == "all" else [mapping.get(cache_type)]
    if not targets or targets[0] is None:
        return jsonify(error="Unknown cache type"), 400
    for target in targets:
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
        target.mkdir(parents=True, exist_ok=True)
    return jsonify(ok=True)

@app.get("/api/storage-policy")
def storage_policy():
    return jsonify(
        local_only=True,
        project_root=str(BASE_DIR),
        hf_home=os.environ.get("HF_HOME"),
        torch_home=os.environ.get("TORCH_HOME"),
        transformers_cache=os.environ.get("TRANSFORMERS_CACHE"),
        pip_cache=os.environ.get("PIP_CACHE_DIR"),
        temp=os.environ.get("TEMP")
    )

if __name__=="__main__":
    import webbrowser
    threading.Timer(1.0,lambda:webbrowser.open("http://127.0.0.1:8080")).start()
    app.run(host="127.0.0.1",port=8080,debug=False,threaded=True)
