@echo off
setlocal EnableExtensions
title ChronosImage AI Studio v5 - Clean OLD C Drive Cache

echo ============================================================
echo This tool removes OLD AI caches from your Windows user folder.
echo It does NOT delete Documents, Pictures, Downloads, or projects.
echo ============================================================
echo.
echo The following folders may be removed:
echo %USERPROFILE%\.cache\huggingface
echo %USERPROFILE%\.cache\torch
echo %LOCALAPPDATA%\pip\Cache
echo %LOCALAPPDATA%\NVIDIA\DXCache
echo %LOCALAPPDATA%\NVIDIA\GLCache
echo %TEMP%\huggingface
echo.
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0

call :RemoveFolder "%USERPROFILE%\.cache\huggingface"
call :RemoveFolder "%USERPROFILE%\.cache\torch"
call :RemoveFolder "%LOCALAPPDATA%\pip\Cache"
call :RemoveFolder "%LOCALAPPDATA%\NVIDIA\DXCache"
call :RemoveFolder "%LOCALAPPDATA%\NVIDIA\GLCache"
call :RemoveFolder "%TEMP%\huggingface"

echo.
echo Running pip cache purge when pip is available...
where pip >nul 2>nul
if not errorlevel 1 pip cache purge

echo.
echo Cleanup completed.
echo New v5 caches are stored inside this project folder.
pause
exit /b 0

:RemoveFolder
if exist "%~1" (
  echo Removing: %~1
  rmdir /s /q "%~1"
) else (
  echo Not found: %~1
)
exit /b 0
