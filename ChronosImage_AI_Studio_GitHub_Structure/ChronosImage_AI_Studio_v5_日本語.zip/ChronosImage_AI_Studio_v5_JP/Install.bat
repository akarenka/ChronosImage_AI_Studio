@echo off
cd /d "%~dp0"
title AI Image Studio v2 Installer
call Install_AI_Requirements.bat
