@echo off
setlocal
title ChronosImage AI Studio v5 - Scan C Drive AI Cache

echo === Old AI cache locations ===
for %%D in (
  "%USERPROFILE%\.cache\huggingface"
  "%USERPROFILE%\.cache\torch"
  "%LOCALAPPDATA%\pip\Cache"
  "%LOCALAPPDATA%\NVIDIA\DXCache"
  "%LOCALAPPDATA%\NVIDIA\GLCache"
) do (
  if exist "%%~D" (
    echo.
    echo [FOUND] %%~D
    powershell -NoProfile -Command "$p='%%~D'; $s=(Get-ChildItem -LiteralPath $p -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum; '{0:N2} GB' -f ($s/1GB)"
  ) else (
    echo [NOT FOUND] %%~D
  )
)
echo.
pause
