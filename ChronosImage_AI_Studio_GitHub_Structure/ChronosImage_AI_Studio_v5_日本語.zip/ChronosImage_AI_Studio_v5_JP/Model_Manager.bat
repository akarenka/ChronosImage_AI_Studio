@echo off
cd /d "%~dp0"
title ChronosImage AI Studio v4 Model Manager

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run Install_v4_Full.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"

:menu
cls
echo ====================================================
echo ChronosImage AI Studio v4 - Model Manager
echo ====================================================
python model_manager.py status
echo.
echo 1. Download / resume SDXL Base 1.0
echo 2. Download / resume SDXL OpenPose ControlNet
echo 3. Download / resume OpenPose Annotators
echo 4. Download / resume SDXL VAE
echo 5. Download / resume Stable Diffusion 1.5
echo 6. Download complete SDXL ControlNet set
echo 7. Open models folder
echo 0. Exit
echo.
set /p choice=Select: 

if "%choice%"=="1" python model_manager.py download sdxl
if "%choice%"=="2" python model_manager.py download openpose-sdxl
if "%choice%"=="3" python model_manager.py download annotators
if "%choice%"=="4" python model_manager.py download vae
if "%choice%"=="5" python model_manager.py download sd15
if "%choice%"=="6" (
  python model_manager.py download sdxl
  python model_manager.py download openpose-sdxl
  python model_manager.py download annotators
  python model_manager.py download vae
)
if "%choice%"=="7" start "" "%CD%\models"
if "%choice%"=="0" exit /b 0
pause
goto menu
