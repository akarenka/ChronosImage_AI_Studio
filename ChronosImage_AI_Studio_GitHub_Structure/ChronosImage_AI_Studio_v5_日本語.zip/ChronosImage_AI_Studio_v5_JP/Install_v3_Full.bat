@echo off
cd /d "%~dp0"
title ChronosImage AI Studio v3 Full Installer
call Install.bat
if not exist ".venv\Scripts\python.exe" exit /b 1
call ".venv\Scripts\activate.bat"
python -m pip install opencv-python numpy psutil requests
echo.
echo Core v3 packages installed.
echo Optional CodeFormer, GFPGAN, ESRGAN, ComfyUI, AUTOMATIC1111 and kohya_ss
echo require their own model files or official folders.
pause
