# ChronosImage AI Studio v5

## インストール

1. Install_v5_Full.bat を実行
2. Model_Manager.bat で必要なモデルをダウンロード
3. Run_v5.bat を実行

## 主な機能

- Flask アクセスログを抑制する静かなコンソール
- オフラインモデルマネージャー
- ControlNet / Img2Img
- LoRA 学習準備
- ローカルキャッシュ管理
- C ドライブ保護
- 画像履歴・出力管理

キャッシュはプロジェクト内の `cache/` フォルダーに保存されます。
