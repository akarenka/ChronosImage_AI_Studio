@echo off
cd /d "%~dp0"
title AI Image Studio v2
call start_server.bat
