@echo off
cd /d "%~dp0"
title AI Image Studio v2 Update
if not exist ".venv\Scripts\python.exe" (
  echo Run Install.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install --upgrade -r requirements.txt
pause
