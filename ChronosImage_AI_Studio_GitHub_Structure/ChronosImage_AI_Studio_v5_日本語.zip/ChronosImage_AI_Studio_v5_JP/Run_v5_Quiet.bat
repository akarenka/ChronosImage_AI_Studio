@echo off
setlocal
cd /d "%~dp0"
title ChronosImage AI Studio v5 Quiet Console
set "WERKZEUG_RUN_MAIN=true"
call Run_v5.bat
