@echo off
cd /d "%~dp0"
if exist "stable-diffusion-webui\webui-user.bat" (
  call "stable-diffusion-webui\webui-user.bat"
) else (
  echo AUTOMATIC1111 was not found in %CD%\stable-diffusion-webui
  pause
)
