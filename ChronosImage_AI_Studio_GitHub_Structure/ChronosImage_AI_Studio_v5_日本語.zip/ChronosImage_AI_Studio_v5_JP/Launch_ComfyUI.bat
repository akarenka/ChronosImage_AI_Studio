@echo off
cd /d "%~dp0"
if exist "ComfyUI\run_nvidia_gpu.bat" (
  call "ComfyUI\run_nvidia_gpu.bat"
) else (
  echo ComfyUI was not found in %CD%\ComfyUI
  echo Place the official portable ComfyUI folder here.
  pause
)
