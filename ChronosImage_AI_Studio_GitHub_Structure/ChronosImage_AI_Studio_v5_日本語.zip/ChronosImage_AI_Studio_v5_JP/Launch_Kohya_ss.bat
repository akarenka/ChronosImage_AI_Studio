@echo off
cd /d "%~dp0"
if exist "kohya_ss\gui.bat" (
  call "kohya_ss\gui.bat"
) else (
  echo kohya_ss was not found in %CD%\kohya_ss
  pause
)
