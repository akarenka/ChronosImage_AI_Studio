@echo off
cd /d "%~dp0"
call ".venv\Scripts\activate.bat"
echo === Python ===
python --version
echo.
echo === Torch / CUDA ===
python -c "import torch; print('torch=',torch.__version__); print('cuda=',torch.cuda.is_available()); print('gpu=',torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None')"
echo.
echo === Hugging Face connection ===
python -c "from huggingface_hub import model_info; print(model_info('stabilityai/stable-diffusion-xl-base-1.0').modelId)"
echo.
echo === Disk free space ===
powershell -NoProfile -Command "Get-PSDrive -PSProvider FileSystem | Select Name,@{N='FreeGB';E={[math]::Round($_.Free/1GB,1)}}"
pause
