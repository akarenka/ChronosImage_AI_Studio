@echo off
cd /d "%~dp0"
start cmd.exe /K "cd /d %~dp0"
