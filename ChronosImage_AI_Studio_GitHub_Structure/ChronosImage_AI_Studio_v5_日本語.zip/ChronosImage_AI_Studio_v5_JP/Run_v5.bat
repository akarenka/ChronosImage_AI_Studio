@echo off
setlocal
cd /d "%~dp0"
title ChronosImage AI Studio v5

set "HF_HOME=%CD%\cache\huggingface"
set "HF_HUB_CACHE=%CD%\cache\huggingface\hub"
set "HUGGINGFACE_HUB_CACHE=%CD%\cache\huggingface\hub"
set "TORCH_HOME=%CD%\cache\torch"
set "TRANSFORMERS_CACHE=%CD%\cache\transformers"
set "PIP_CACHE_DIR=%CD%\cache\pip"
set "TMP=%CD%\cache\temp"
set "TEMP=%CD%\cache\temp"
set "HF_HUB_DOWNLOAD_TIMEOUT=600"
set "HF_HUB_ETAG_TIMEOUT=60"

if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Run Install_v5_Full.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python server.py
pause
