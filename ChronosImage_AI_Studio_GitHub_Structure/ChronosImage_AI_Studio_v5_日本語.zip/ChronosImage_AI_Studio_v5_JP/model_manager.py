from __future__ import annotations
import argparse
import json
import os
import shutil
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
CACHE = BASE / "cache" / "huggingface"

CATALOG = {
    "sdxl": {
        "repo": "stabilityai/stable-diffusion-xl-base-1.0",
        "target": BASE / "models" / "checkpoints" / "sdxl-base-1.0",
    },
    "openpose-sdxl": {
        "repo": "thibaud/controlnet-openpose-sdxl-1.0",
        "target": BASE / "models" / "controlnet" / "openpose-sdxl",
    },
    "annotators": {
        "repo": "lllyasviel/Annotators",
        "target": BASE / "models" / "controlnet" / "annotators",
    },
    "vae": {
        "repo": "madebyollin/sdxl-vae-fp16-fix",
        "target": BASE / "models" / "vae" / "sdxl-vae-fp16-fix",
    },
    "sd15": {
        "repo": "runwayml/stable-diffusion-v1-5",
        "target": BASE / "models" / "checkpoints" / "sd15",
    },
}

def size_of(path: Path) -> int:
    total = 0
    if path.exists():
        for p in path.rglob("*"):
            if p.is_file():
                try: total += p.stat().st_size
                except OSError: pass
    return total

def human(n: int) -> str:
    value = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.1f} {unit}"
        value /= 1024

def status() -> None:
    for key, item in CATALOG.items():
        target = item["target"]
        installed = target.exists() and any(target.rglob("*"))
        print(f"{key:14} {'INSTALLED' if installed else 'MISSING':10} {human(size_of(target)):>10}  {target}")

def download(key: str) -> None:
    if key not in CATALOG:
        raise SystemExit(f"Unknown model: {key}")
    from huggingface_hub import snapshot_download
    item = CATALOG[key]
    target: Path = item["target"]
    target.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "600")
    os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "60")
    print(f"Downloading/resuming: {item['repo']}")
    print(f"Target: {target}")
    snapshot_download(
        repo_id=item["repo"],
        local_dir=target,
        local_dir_use_symlinks=False,
        resume_download=True,
        max_workers=2,
        cache_dir=CACHE,
    )
    print("Completed:", target)

def delete(key: str) -> None:
    if key not in CATALOG:
        raise SystemExit(f"Unknown model: {key}")
    target: Path = CATALOG[key]["target"]
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True, exist_ok=True)
    print("Deleted:", target)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["status", "download", "delete"])
    parser.add_argument("model", nargs="?")
    args = parser.parse_args()
    if args.action == "status":
        status()
    elif not args.model:
        raise SystemExit("Model key is required.")
    elif args.action == "download":
        download(args.model)
    else:
        delete(args.model)
